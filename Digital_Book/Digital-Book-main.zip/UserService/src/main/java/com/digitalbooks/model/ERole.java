package com.digitalbooks.model;

public enum ERole {
	ROLE_USER, ROLE_READER,ROLE_AUTHOR, ROLE_ADMIN
}
